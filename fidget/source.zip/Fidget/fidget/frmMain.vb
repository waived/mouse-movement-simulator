﻿Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Windows.Forms
Imports System.Threading.Tasks

Public Class frmMain
    Public Shared K1 As Keys = System.Windows.Forms.Keys.Menu
    Public Shared K2 As Keys = System.Windows.Forms.Keys.F9

#Region "Mouse Declarations"
    ' Mouse event flags
    Private Const MOUSEEVENTF_LEFTDOWN As UInteger = &H2
    Private Const MOUSEEVENTF_LEFTUP As UInteger = &H4

    ' Screen dimensions
    Private screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
    Private screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

    ' API function to check key state
    <DllImport("user32.dll")>
    Private Shared Function GetAsyncKeyState(vKey As Keys) As Short
    End Function

    Private _active As Boolean = False

    ' Declare required functions for mouse movement and clicking
    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function SetCursorPos(x As Integer, y As Integer) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function mouse_event(dwFlags As UInteger, dx As Integer, dy As Integer, dwData As UInteger, dwExtraInfo As UInteger) As Integer
    End Function
#End Region

#Region "Form Handling"
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        comboK1.SelectedIndex = 0
        comboK2.SelectedIndex = 8
    End Sub

    Private Sub frmMain_Closing(sender As Object, e As EventArgs) Handles MyBase.Closing
        _active = False
    End Sub

    Private Sub frmMain_Min(sender As Object, e As EventArgs) Handles MyBase.Resize
        If WindowState = WindowState.Minimized Then
            Me.Hide()
            trayIcon.Visible = True
            trayIcon.BalloonTipTitle = "Fidget 1.9"
            trayIcon.BalloonTipText = "Minimized. Double-click icon to open!"
            trayIcon.BalloonTipIcon = ToolTipIcon.Info
            trayIcon.ShowBalloonTip(10000)
        End If
    End Sub

    Private Sub trayIcon_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles trayIcon.MouseDoubleClick
        Me.Show()
        Me.WindowState = WindowState.Normal
        trayIcon.Visible = False
    End Sub

    Private Sub RadioButton_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged, RadioButton2.CheckedChanged
        If RadioButton1.Checked Then
            numMin.Value = 15
            numMax.Value = 35
            numMax.Enabled = False
            lb1.ForeColor = Color.Silver
            lb2.ForeColor = Color.Silver
        ElseIf RadioButton2.Checked Then
            numMin.Value = 15
            numMax.Value = 35
            numMax.Enabled = True
            lb1.ForeColor = Color.Black
            lb2.ForeColor = Color.Black
        End If
    End Sub

    Private Sub comboK1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboK1.SelectedIndexChanged
        Select Case comboK1.Text
            Case "ALT" : K1 = Windows.Forms.Keys.Menu
            Case "SHIFT" : K1 = Windows.Forms.Keys.Shift
            Case "CTRL" : K1 = Windows.Forms.Keys.Control
        End Select
    End Sub

    Private Sub comboK2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboK2.SelectedIndexChanged
        K2 = CType([Enum].GetValues(GetType(Keys)).Cast(Of Keys)().FirstOrDefault(Function(k) comboK2.Text = k.ToString()), Keys)
    End Sub

    Private Sub btnCtrl_Click(sender As Object, e As EventArgs) Handles btnCtrl.Click
        If btnCtrl.Text = "Simulate Movement" Then
            ' Start simulation
            btnCtrl.Text = "End Simulation"
            If numMin.Value > numMax.Value Then numMin.Value = numMax.Value
            _active = True
            Task.Run(AddressOf KeyWait)
            Task.Run(AddressOf DoWork)
            _gui(1) : _form(0)
        Else
            ' Stop simulation
            _active = False
            btnCtrl.Text = "Simulate Movement"
            _gui(0)
        End If
    End Sub

    Public Function _form(val As Integer)
        If val = 0 Then
            ' Minimize form
            Me.WindowState = WindowState.Minimized
            Me.Hide()
            trayIcon.Visible = True
            trayIcon.BalloonTipTitle = "Fidget 1.9"
            trayIcon.BalloonTipText = "Minimized. Double-click icon to open!"
            trayIcon.BalloonTipIcon = ToolTipIcon.Info
            trayIcon.ShowBalloonTip(10000)
        Else
            ' Show form
            Me.Show()
            Me.WindowState = WindowState.Normal
            trayIcon.Visible = False
        End If
    End Function

    Public Function _gui(val As Integer)
        If val = 0 Then
            ' Unlock UI controls
            chkClick.Enabled = True
            chkReturn.Enabled = True
            numMin.Enabled = True
            RadioButton1.Enabled = True
            RadioButton2.Enabled = True
            comboK1.Enabled = True
            comboK2.Enabled = True
            comboK1.SelectedIndex = 0
            comboK2.SelectedIndex = 8
            numMin.Value = 15
            numMax.Value = 35
            numMax.Enabled = False
            lb1.ForeColor = Color.Silver
            lb2.ForeColor = Color.Silver
        Else
            ' Lock UI controls
            chkClick.Enabled = False
            chkReturn.Enabled = False
            numMax.Enabled = False
            numMin.Enabled = False
            RadioButton1.Enabled = False
            RadioButton2.Enabled = False
            comboK1.Enabled = False
            comboK2.Enabled = False
        End If
    End Function
#End Region

#Region "User Events"
    ' Wait for the keys to be pressed
    Private Sub KeyWait()
        While _active
            If (GetAsyncKeyState(K2) < 0) And (GetAsyncKeyState(K1) < 0) Then
                _active = False
                _form(1)
            End If
            Task.Delay(100).Wait()
        End While
    End Sub

    ' Perform simulated mouse movement and clicks
    Private Sub DoWork()
        Dim random As New Random()
        While _active
            Dim mousePosition As Point = Cursor.Position
            Dim x As Integer = random.Next(0, screenWidth)
            Dim y As Integer = random.Next(0, screenHeight)

            ' Move the cursor to a random position
            SetCursorPos(x, y)

            If chkReturn.Checked Then
                ' Return cursor to original position
                Task.Delay(100).Wait()
                SetCursorPos(mousePosition.X, mousePosition.Y)
            End If

            If chkClick.Checked Then
                ' Simulate left mouse click
                Task.Delay(100).Wait()
                mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)
                mouse_event(MOUSEEVENTF_LEFTUP, x, y, 0, 0)
            End If

            ' Pause before next movement
            Dim sleep As Integer = random.Next(numMin.Value * 1000, numMax.Value * 1000)
            Task.Delay(sleep).Wait()
        End While

        ' Unlock the GUI when done
        Invoke(Sub() btnCtrl.Enabled = True)
        _gui(1)
    End Sub
#End Region
End Class
