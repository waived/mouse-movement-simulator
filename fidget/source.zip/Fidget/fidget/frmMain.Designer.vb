﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lb1 = New System.Windows.Forms.Label()
        Me.numMax = New System.Windows.Forms.NumericUpDown()
        Me.lb2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.numMin = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.comboK2 = New System.Windows.Forms.ComboBox()
        Me.comboK1 = New System.Windows.Forms.ComboBox()
        Me.btnCtrl = New System.Windows.Forms.Button()
        Me.trayIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkClick = New System.Windows.Forms.CheckBox()
        Me.chkReturn = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.numMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lb1)
        Me.GroupBox1.Controls.Add(Me.numMax)
        Me.GroupBox1.Controls.Add(Me.lb2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.numMin)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(232, 119)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Move every..."
        '
        'lb1
        '
        Me.lb1.AutoSize = True
        Me.lb1.ForeColor = System.Drawing.Color.Silver
        Me.lb1.Location = New System.Drawing.Point(128, 62)
        Me.lb1.Name = "lb1"
        Me.lb1.Size = New System.Drawing.Size(61, 16)
        Me.lb1.TabIndex = 9
        Me.lb1.Text = "Seconds"
        '
        'numMax
        '
        Me.numMax.Enabled = False
        Me.numMax.Location = New System.Drawing.Point(131, 81)
        Me.numMax.Maximum = New Decimal(New Integer() {276447231, 23283, 0, 0})
        Me.numMax.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numMax.Name = "numMax"
        Me.numMax.Size = New System.Drawing.Size(84, 22)
        Me.numMax.TabIndex = 8
        Me.numMax.Value = New Decimal(New Integer() {35, 0, 0, 0})
        '
        'lb2
        '
        Me.lb2.AutoSize = True
        Me.lb2.ForeColor = System.Drawing.Color.Silver
        Me.lb2.Location = New System.Drawing.Point(107, 83)
        Me.lb2.Name = "lb2"
        Me.lb2.Size = New System.Drawing.Size(18, 16)
        Me.lb2.TabIndex = 7
        Me.lb2.Text = "to"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Seconds"
        '
        'numMin
        '
        Me.numMin.Location = New System.Drawing.Point(17, 81)
        Me.numMin.Maximum = New Decimal(New Integer() {276447231, 23283, 0, 0})
        Me.numMin.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numMin.Name = "numMin"
        Me.numMin.Size = New System.Drawing.Size(84, 22)
        Me.numMin.TabIndex = 5
        Me.numMin.Value = New Decimal(New Integer() {15, 0, 0, 0})
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(81, 25)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(66, 20)
        Me.RadioButton2.TabIndex = 2
        Me.RadioButton2.Text = "Range"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(17, 25)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(58, 20)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Fixed"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.comboK2)
        Me.GroupBox2.Controls.Add(Me.comboK1)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 137)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(232, 69)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Press to quit"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(109, 31)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 16)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "+"
        '
        'comboK2
        '
        Me.comboK2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboK2.FormattingEnabled = True
        Me.comboK2.Items.AddRange(New Object() {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"})
        Me.comboK2.Location = New System.Drawing.Point(131, 28)
        Me.comboK2.Name = "comboK2"
        Me.comboK2.Size = New System.Drawing.Size(84, 24)
        Me.comboK2.TabIndex = 3
        '
        'comboK1
        '
        Me.comboK1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboK1.FormattingEnabled = True
        Me.comboK1.Items.AddRange(New Object() {"ALT", "SHIFT", "CTRL"})
        Me.comboK1.Location = New System.Drawing.Point(17, 28)
        Me.comboK1.Name = "comboK1"
        Me.comboK1.Size = New System.Drawing.Size(84, 24)
        Me.comboK1.TabIndex = 2
        '
        'btnCtrl
        '
        Me.btnCtrl.BackColor = System.Drawing.SystemColors.Control
        Me.btnCtrl.Location = New System.Drawing.Point(12, 301)
        Me.btnCtrl.Name = "btnCtrl"
        Me.btnCtrl.Size = New System.Drawing.Size(232, 37)
        Me.btnCtrl.TabIndex = 2
        Me.btnCtrl.Text = "Simulate Movement"
        Me.btnCtrl.UseVisualStyleBackColor = False
        '
        'trayIcon
        '
        Me.trayIcon.Icon = CType(resources.GetObject("trayIcon.Icon"), System.Drawing.Icon)
        Me.trayIcon.Text = "Fidget 1.9"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkClick)
        Me.GroupBox3.Controls.Add(Me.chkReturn)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 212)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(233, 83)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Settings"
        '
        'chkClick
        '
        Me.chkClick.AutoSize = True
        Me.chkClick.Location = New System.Drawing.Point(17, 50)
        Me.chkClick.Name = "chkClick"
        Me.chkClick.Size = New System.Drawing.Size(173, 20)
        Me.chkClick.TabIndex = 1
        Me.chkClick.Text = "Left-click after movement"
        Me.chkClick.UseVisualStyleBackColor = True
        '
        'chkReturn
        '
        Me.chkReturn.AutoSize = True
        Me.chkReturn.Location = New System.Drawing.Point(17, 24)
        Me.chkReturn.Name = "chkReturn"
        Me.chkReturn.Size = New System.Drawing.Size(206, 20)
        Me.chkReturn.TabIndex = 0
        Me.chkReturn.Text = "Return cursor to same location"
        Me.chkReturn.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(257, 351)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnCtrl)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fidget 1.9"
        Me.TopMost = True
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.numMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents lb1 As Label
    Friend WithEvents numMax As NumericUpDown
    Friend WithEvents lb2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents numMin As NumericUpDown
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents comboK2 As ComboBox
    Friend WithEvents comboK1 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnCtrl As Button
    Friend WithEvents trayIcon As NotifyIcon
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents chkClick As CheckBox
    Friend WithEvents chkReturn As CheckBox
End Class
